#ifndef __wasilibc___typedef_mode_t_h
#define __wasilibc___typedef_mode_t_h

typedef unsigned mode_t;

#endif
